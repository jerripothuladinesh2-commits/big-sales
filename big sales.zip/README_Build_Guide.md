# Retail Sales Performance Dashboard: Levels 3, 4 and 5

Power BI `.pbix` files can only be saved from Power BI Desktop, so this folder gives you a finished
interactive dashboard (`Retail_Sales_Dashboard.html`) that shows the exact end result, plus everything
needed to rebuild it in Power BI in about 20 minutes.

## Important data note
`cleaned_big_mart_sales_csv.xlsx` has **no sales or quantity column** (it is the Big Mart test split).
So **Total Sales = Item_MRP** per listing. Say this in your video and LinkedIn post.
Two issues were also still in the file: Item_Fat_Content has LF / low fat / reg labels, and
Outlet_Size is blank in 1,606 rows. Both are fixed in `DAX_and_PowerQuery.txt` and
`Retail_Sales_Final_Clean.csv`.

## Setup (2 min)
1. Home > Get data > Text/CSV > `Retail_Sales_Final_Clean.csv` (or use the M code) > Load.
2. View > Themes > Browse for themes > `Retail_Sales_Theme.json`.
3. Add the measures from `DAX_and_PowerQuery.txt` (Table tools > New measure).

## Level 3: Basic visualizations
| Task | Visual | Fields |
|---|---|---|
| Sales by product category | Clustered **bar** chart | Y: Item_Type, X: Total Sales (sort descending) |
| Sales by outlet | Clustered **column** chart | X: Outlet_Identifier, Y: Total Sales |
| Product and sales values | **Table** | Item_Identifier, Item_Type, Total Sales |
Format each: Format pane > General > Title (on, descriptive text), Visual > Data labels (on),
axis titles on.

## Level 4: Interactivity and insights
1. **Slicers** (Slicer visual): Item_Type (Dropdown style), Outlet_Identifier, Outlet_Location_Type,
   Outlet_Type, Item_Fat_Content (Tile/Button style).
2. **KPI cards** (use the *Card* or *Multi-row card* visual): Total Sales, Items Listed, Avg Price,
   Unique Products, Top Product.
3. **Top-performing products**: bar chart, Y: Item_Identifier, X: Total Sales,
   Filters pane > Item_Identifier > Filter type **Top N** = 10 by Total Sales.
4. **Check interactions**: Format > Edit interactions. Make slicers filter everything. Click a bar
   to confirm other visuals cross-filter.

## Level 5: Final dashboard
Layout on one 16:9 page (1280 x 720), matching the HTML:
```
[ Title bar: Retail Sales Performance Dashboard ]
[ Slicers row ]
[ KPI cards x5 ]
[ Sales by category (bar) | Sales by outlet (column) ]
[ Top 10 products        | Product sales table      ]
```
- Theme: `Retail_Sales_Theme.json` (navy #14213D, blue #2F5D9E, orange #F28C28 for highlights).
- Add a text box title and a text box for each section heading (Filters, KPIs, Sales by category and
  outlet, Top performers).
- Review: cards equal the sum of the bar chart; clear all slicers and check Total Sales matches the
  table total; no overlapping visuals; View > Page view > Fit to page.
- Save as `Retail_Sales_Dashboard.pbix`. Keep one file per level, as the task sheet requires
  (save a copy after each level).

## Video and LinkedIn
Record 2 to 3 minutes: data note, Level 3 charts, Level 4 slicers and cards, Level 5 final page.
Tag Sysslan IT Solutions and use #SysslanITSolutions #Sysslan #SysslanProjects #PowerBI #DataAnalytics
